using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Win32;

namespace VisiblePlacesManager
{
    public class VisiblePlace
    {
        public string Name { get; set; } = string.Empty;
        public byte[] Guid { get; set; } = Array.Empty<byte>();
        public bool IsSelected { get; set; }
    }

    public partial class MainForm : Form
    {
        private Dictionary<string, VisiblePlace>? places;
        private FlowLayoutPanel? checkboxPanel;
        private Button? applyButton;
        private Button? toggleAllButton;
        private bool allSelected = false;

        public MainForm()
        {
            InitializeComponents();
            LoadVisiblePlaces();
        }

        private void InitializeComponents()
        {
            this.Text = "Dossiers Menu Démarrer";
            this.Size = new Size(400, 500);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            checkboxPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                AutoScroll = true,
                Padding = new Padding(10),
                WrapContents = false
            };

            var buttonPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 60,
                Padding = new Padding(10)
            };

            applyButton = new Button
            {
                Text = "Appliquer",
                Width = 120,
                Location = new Point(20, 15)
            };
            applyButton.Click += Apply_Click;

            toggleAllButton = new Button
            {
                Text = "Tout sélectionner",
                Width = 120,
                Location = new Point(buttonPanel.Width - 40, 15)
            };
            toggleAllButton.Click += ToggleAll_Click;

            buttonPanel.Controls.Add(applyButton);
            buttonPanel.Controls.Add(toggleAllButton);

            this.Controls.Add(checkboxPanel);
            this.Controls.Add(buttonPanel);
        }

        private void LoadVisiblePlaces()
        {
            places = new Dictionary<string, VisiblePlace>();
            bool regFilesFound = false;
            string currentDir = Directory.GetCurrentDirectory();

            // Essayer de charger depuis les fichiers .reg s'ils existent
            try
            {
                foreach (string file in Directory.GetFiles(currentDir, "Visible Places*.reg"))
                {
                    string content = File.ReadAllText(file);
                    string originalName = Path.GetFileNameWithoutExtension(file).Replace("Visible Places ", "");
                    byte[]? guid = ParseHexValue(content);

                    if (guid != null)
                    {
                        string translatedName = Translations.PlaceNames.ContainsKey(originalName) 
                            ? Translations.PlaceNames[originalName] 
                            : originalName;

                        places.Add(translatedName, new VisiblePlace 
                        { 
                            Name = translatedName, 
                            Guid = guid, 
                            IsSelected = false 
                        });
                        regFilesFound = true;
                    }
                }
            }
            catch
            {
                regFilesFound = false;
            }

            // Si aucun fichier .reg n'est trouvé, utiliser les valeurs par défaut
            if (!regFilesFound)
            {
                foreach (var kvp in DefaultRegistryValues.DefaultGuids)
                {
                    string translatedName = Translations.PlaceNames.ContainsKey(kvp.Key) 
                        ? Translations.PlaceNames[kvp.Key] 
                        : kvp.Key;

                    places.Add(translatedName, new VisiblePlace 
                    { 
                        Name = translatedName, 
                        Guid = kvp.Value, 
                        IsSelected = false 
                    });
                }
            }

            // Créer les cases à cocher
            if (checkboxPanel != null)
            {
                foreach (var place in places.Values)
                {
                    var checkbox = new CheckBox
                    {
                        Text = place.Name,
                        AutoSize = true,
                        Margin = new Padding(5)
                    };
                    checkboxPanel.Controls.Add(checkbox);
                }
            }

            // Lire l'état actuel du registre
            try
            {
                using (RegistryKey? key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Start"))
                {
                    if (key != null)
                    {
                        byte[]? currentValue = key.GetValue("VisiblePlaces") as byte[];
                        if (currentValue != null && places != null)
                        {
                            UpdateCheckboxesFromRegistry(currentValue);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de la lecture du registre : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private byte[]? ParseHexValue(string content)
        {
            try
            {
                // Trouve la valeur hex dans le contenu du fichier .reg
                int hexIndex = content.IndexOf("hex:");
                if (hexIndex == -1) return null;

                string hexString = content.Substring(hexIndex + 4)
                    .Replace("\r", "")
                    .Replace("\n", "")
                    .Replace(" ", "")
                    .Replace("\\", "")
                    .Replace(",", "");

                // Convertit la chaîne hex en tableau de bytes
                var bytes = new List<byte>();
                for (int i = 0; i < hexString.Length; i += 2)
                {
                    if (i + 2 <= hexString.Length)
                    {
                        bytes.Add(Convert.ToByte(hexString.Substring(i, 2), 16));
                    }
                }
                return bytes.ToArray();
            }
            catch
            {
                return null;
            }
        }

        private void UpdateCheckboxesFromRegistry(byte[] currentValue)
        {
            if (checkboxPanel == null || places == null) return;

            // Pour chaque GUID de 16 bytes dans la valeur actuelle
            for (int i = 0; i < currentValue.Length; i += 16)
            {
                byte[] guid = new byte[16];
                Array.Copy(currentValue, i, guid, 0, 16);

                // Trouve le VisiblePlace correspondant à ce GUID
                var place = places.Values.FirstOrDefault(p => 
                    p.Guid.SequenceEqual(guid));

                if (place != null)
                {
                    place.IsSelected = true;
                    var checkbox = checkboxPanel.Controls.OfType<CheckBox>()
                        .FirstOrDefault(c => c.Text == place.Name);
                    if (checkbox != null)
                    {
                        checkbox.Checked = true;
                    }
                }
            }
        }

        private void ToggleAll_Click(object? sender, EventArgs e)
        {
            if (checkboxPanel == null || toggleAllButton == null) return;

            allSelected = !allSelected;
            toggleAllButton.Text = allSelected ? "Tout désélectionner" : "Tout sélectionner";

            foreach (CheckBox checkbox in checkboxPanel.Controls.OfType<CheckBox>())
            {
                checkbox.Checked = allSelected;
            }
        }

        private void Apply_Click(object? sender, EventArgs e)
        {
            if (places == null) return;

            try
            {
                // Mettre à jour l'état des places
                if (checkboxPanel != null)
                {
                    foreach (CheckBox checkbox in checkboxPanel.Controls.OfType<CheckBox>())
                    {
                        if (places.ContainsKey(checkbox.Text))
                        {
                            places[checkbox.Text].IsSelected = checkbox.Checked;
                        }
                    }
                }

                // Construire la nouvelle valeur
                var selectedPlaces = places.Values.Where(p => p.IsSelected).ToList();
                byte[] newValue = new byte[selectedPlaces.Count * 16];
                
                for (int i = 0; i < selectedPlaces.Count; i++)
                {
                    Array.Copy(selectedPlaces[i].Guid, 0, newValue, i * 16, 16);
                }

                // Écrire dans le registre
                using (RegistryKey? key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Start", true))
                {
                    if (key != null)
                    {
                        key.SetValue("VisiblePlaces", newValue, RegistryValueKind.Binary);
                        MessageBox.Show("Les modifications ont été appliquées avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        throw new Exception("Impossible d'accéder à la clé de registre");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de l'application des modifications : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
