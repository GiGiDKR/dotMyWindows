namespace VisiblePlacesManager
{
    public static class Translations
    {
        public static readonly Dictionary<string, string> PlaceNames = new()
        {
            { "Download", "Téléchargements" },
            { "Documents", "Documents" },
            { "Pictures", "Images" },
            { "Music", "Musique" },
            { "Videos", "Vidéos" },
            { "Network", "Réseau" },
            { "Settings", "Paramètres" },
            { "User Folder", "Dossier utilisateur" },
            { "File Explorer", "Explorateur de fichiers" }
        };
    }
}
